DROP  SCHEMA IF EXISTS ProjetARENA;
CREATE SCHEMA ProjetARENA ;

CREATE TABLE ProjetARENA.Utilisateur(
`nom` VARCHAR(50) NOT NULL,
`prenom` VARCHAR(50) NOT NULL,
`pseudo` VARCHAR(50) NOT NULL,
`mot_de_passe` VARCHAR(50) NOT NULL,
`email` VARCHAR(50) NOT NULL,
`classe` VARCHAR(50) NOT NULL,
`notif` bool NOT NULL,
PRIMARY KEY (`pseudo`)
);

CREATE TABLE ProjetARENA.Evenement(
`id` int NOT NULL AUTO_INCREMENT,
`nomE` VARCHAR(50) NOT NULL,
`descri` VARCHAR(500) NOT NULL,
`dateE` date NOT NULL,
`plateforme` VARCHAR(50) NOT NULL,
`interhei` bool NOT NULL,
`payant` bool NOT NULL,
PRIMARY KEY (`id`)
)

CREATE TABLE ProjetARENA.EvUt(
`pseudo` VARCHAR(50) NOT NULL,
`id` int NOT NULL AUTO_INCREMENT,
FOREIGN KEY (`id`) REFERENCES Evenement(id),
FOREIGN KEY (`pseudo`) REFERENCES Utilisateur(pseudo)
)