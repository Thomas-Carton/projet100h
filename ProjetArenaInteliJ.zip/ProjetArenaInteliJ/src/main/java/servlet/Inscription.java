package servlet;

import javax.servlet.annotation.WebServlet;


import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;

@WebServlet("/Inscription")
public class Inscription  extends HttpServlet{

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

            PrintWriter out=resp.getWriter();
out.println("            <!DOCTYPE html>");
out.println("<html>");
out.println("<title>Inscription</title>");
out.println("<meta charset=\"UTF-8\">");
out.println("                    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
out.println("                    <link rel=\"stylesheet\" href=\"../CSS/Site.css\">");
out.println("                    <body>");
out.println("");
out.println("<!-- Navbar -->");
out.println("<div class=\"arena-top\">");
out.println("                    <div class=\"arena-bar arena-white arena-wide arena-padding arena-card\">");
out.println("                    <a href=\"Accueil\" class=\"arena-bar-item arena-button\" ><b>ARENA</b> HEI</a>");
out.println("                    <!-- Float links to the right. Hide them on small screens -->");
out.println("    <div class=\"arena-right arena-hide-small\">");
out.println("                    <a href=\"Evenement\" class=\"arena-bar-item arena-button\">Evènements</a>");
out.println("                    <a href=\"Resultat\" class=\"arena-bar-item arena-button\">Résultats</a>");
out.println("                    <a href=\"Contact\" class=\"arena-bar-item arena-button\">Contact</a>");
out.println("                    <a href=\"Connexion\" class=\"arena-bar-item arena-button active\">Inscription</a>");
out.println("                    </div>");
out.println("  </div>");
out.println("</div>");
out.println("<!-- Header -->");
out.println("<header class=\"arena-display-container arena-content arena-wide\" style=\"max-width:1500px;\" id=\"home\">");
out.println("                    <img class=\"arena-image\" src=\"../images/Connexion.jpg\" alt=\"fondecran\" width=\"100%\" height=\"auto\">");
out.println("                    <div class=\"arena-display-middle arena-margin-top arena-center\">");
out.println("                    <h1 class=\"arena-xxlarge arena-text-white\"><span class=\"arena-hide-small arena-text-light-grey\"><b><span class=\"arena-text-white shadow\">INSCRIPTION</span></b></h1>");
out.println("                    </div>");
out.println("</header>");
out.println("");
out.println("<!-- Page content -->");
out.println("  <!-- Connexion Section -->");
out.println("  <div class=\"arena-container arena-padding-32\" id=\"Connexion\">");
out.println("                    <h3 class=\"arena-border-bottom arena-border-light-grey arena-padding-16\">Connexion</h3>");
out.println("                    <p>Veuillez renseigner les différents champs afin de vous inscrire. Le pseudo et le mot de passe seront utilisés pour se connecter.</p>");
out.println("    <form action=\"/action_page.php\" target=\"_blank\" method=\"post\">");
out.println("                    <input class=\"arena-input\" type=\"text\" placeholder=\"Nom\" required name=\"Nom\">");
out.println("                    <input class=\"arena-input\" type=\"text\" placeholder=\"Prenom\" required name=\"Prenom\">");
out.println("                    <input class=\"arena-input arena-section\" type=\"text\" placeholder=\"Email\" required name=\"Email\">");
out.println("                    <input class=\"arena-input arena-section\" type=\"text\" placeholder=\"Classe\" required name=\"Classe\">");
        out.println("                    <input class=\"arena-input arena-section\" type=\"text\" placeholder=\"Pseudo\" required name=\"Pseudo\">");
        out.println("                    <input class=\"arena-input arena-section\" type=\"text\" placeholder=\"Mot de passe\" required name=\"Mot de passe\">");
out.println("                    <div class=\"arena-input\" ><input type=\"checkbox\" value=\"Notifications\" id=\"Notif\" name=\"Notifications\"><label for=\"Notif\">Souhaitez-vous vous abonner à la newsletter ?</label></div>");
out.println("                    <button class=\"arena-button arena-black arena-section\" type=\"submit\">");
out.println("                    <i class=\"fa fa-paper-plane\"></i> S'inscrire");
out.println("                    </button>");
out.println("    </form>");
out.println("  </div>");
            out.println("</body>");
            out.println("</html>");




    }
}
