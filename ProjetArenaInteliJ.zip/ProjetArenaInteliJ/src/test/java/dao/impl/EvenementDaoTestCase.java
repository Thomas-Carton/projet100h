package dao.impl;

import dao.EvenementDao;
import entities.Evenement;
import org.junit.Before;
import org.junit.Test;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.tuple;

public class EvenementDaoTestCase {


        private EvenementDao evenementDao=new EvenementDaoImpl();

        @Before
        public void initDb() throws Exception {
            try (Connection connection = DataSourceProvider.getDataSource().getConnection();
                 Statement stmt = connection.createStatement()) {
                stmt.executeUpdate("DELETE FROM evenement");
                stmt.executeUpdate("INSERT INTO `evenement`(`nomE`,`descri`,`dateE`,`plateforme`,`interhei`,`payant`) VALUES ('entre1','descri1','2018-02-19','ps4',1,1)");
                stmt.executeUpdate("INSERT INTO `evenement`(`nomE`,`descri`,`dateE`,`plateforme`,`interhei`,`payant`) VALUES ('entre2','descri2','2018-02-18','ordi',0,1)");
                stmt.executeUpdate("INSERT INTO `evenement`(`nomE`,`descri`,`dateE`,`plateforme`,`interhei`,`payant`) VALUES ('entre3','descri3','2018-02-17','xbox',1,0)");
            }
        }

        @Test
        public void shouldListEvenement() {
            List<Evenement> evenement=evenementDao.listeEvenement();
            assertThat(evenement).hasSize(3);
            assertThat(evenement).extracting("nomE","descri","dateE","plateforme","interhei","payant").containsOnly(tuple("entre1","descri1",2018-02-19,"ps4",true,true), tuple("entre2","descri2",2018-02-18,"ordi",false,true), tuple("entre3","descri3",2018-02-18,"xbox",true,false));
        }
        @Test
        public void shouldGetEvenement() {
            // WHEN
            Evenement evenement = evenementDao.getEvenement("nomE");
            // THEN
            assertThat(evenement).isNotNull();
            assertThat(evenement.getNomE()).isEqualTo("nom1");
            assertThat(evenement.getDescri()).isEqualTo("prenom1");
            assertThat(evenement.getPseudo()).isEqualTo("pseudo1");
            assertThat(evenement.getMot_de_passe()).isEqualTo("mdp1");
            assertThat(evenement.getEmail()).isEqualTo("test1@exemple");
            assertThat(evenement.getClasse()).isEqualTo("H41");
            assertThat(evenement.getNotif()).isEqualTo(true);
        }

        @Test
        public void shouldGetId() {
            // WHEN
            String evenement = evenementDao.getId("pseudo1");
            // THEN
            assertThat(evenement).isNotNull();
            assertThat(evenement).isEqualTo("mdp1");

        }

        @Test
        public void shouldNotGetUnknownEvenement() {
            // WHEN
            Evenement evenement = evenementDao.getEvenement("pseudo-1");
            // THEN
            assertThat(evenement).isNull();
        }

        @Test
        public void shouldAddEvenement() throws Exception {

            Evenement event=new Evenement("exnom","exprenom","expseudo","exmdp","extest@exemple","exH",true);
            // WHEN
            Evenement createdEvenement=evenementDao.addEvenement(event);

            assertThat(createdEvenement).isNotNull();
            assertThat(createdEvenement.getNom()).isEqualTo("exnom");
            assertThat(createdEvenement.getPrenom()).isEqualTo("exprenom");
            assertThat(createdEvenement.getPseudo()).isEqualTo("expseudo");
            assertThat(createdEvenement.getMot_de_passe()).isEqualTo("exmdp");
            assertThat(createdEvenement.getEmail()).isEqualTo("extest@exemple");
            assertThat(createdEvenement.getClasse()).isEqualTo("exH");
            assertThat(createdEvenement.getNotif()).isEqualTo(true);


            // THEN
            try (Connection connection = DataSourceProvider.getDataSource().getConnection();
                 Statement stmt = connection.createStatement()) {
                try (ResultSet rs = stmt.executeQuery("SELECT * FROM Utilisateur WHERE pseudo = 'expseudo'")) {
                    assertThat(rs.next()).isTrue();
                    assertThat(rs.getString("nom")).isEqualTo("exnom");
                    assertThat(rs.getString("prenom")).isEqualTo("exprenom");
                    assertThat(rs.getString("pseudo")).isEqualTo("expseudo");
                    assertThat(rs.getString("mot_de_passe")).isEqualTo("exmdp");
                    assertThat(rs.getString("email")).isEqualTo("extest@exemple");
                    assertThat(rs.getString("classe")).isEqualTo("exH");
                    assertThat(rs.getBoolean("notif")).isEqualTo(true);
                    assertThat(rs.next()).isFalse();
                }
            }
        }
    }

}
