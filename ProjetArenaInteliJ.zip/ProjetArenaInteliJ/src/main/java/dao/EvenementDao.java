package dao;

import entities.Evenement;

import java.util.List;

public interface EvenementDao {

    public List<Evenement> listeEvenement();

    public Evenement getEvenement(String nomE);

    public String getId(String nomE);

    public Evenement addEvenement(Evenement evenement);
}
