DROP  SCHEMA IF EXISTS ProjetARENA;
CREATE SCHEMA ProjetARENA ;

CREATE TABLE ProjetARENA.Utilisateur(
`nom` VARCHAR(50) NOT NULL,
`prenom` VARCHAR(50) NOT NULL,
`pseudo` VARCHAR(50) NOT NULL,
`mot_de_passe` VARCHAR(50) NOT NULL,
`email` VARCHAR(50) NOT NULL,
`classe` VARCHAR(50) NOT NULL,
`notif` bool NOT NULL,
PRIMARY KEY (`pseudo`)
);