package servlet;


import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.WebContext;
import org.thymeleaf.templateresolver.ServletContextTemplateResolver;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

@WebServlet("/Accueil")
public class Accueil extends HttpServlet {

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        String identifConnecte = (String) req.getSession().getAttribute("pseudo");

        String format = "yy-MM-dd";

        java.text.SimpleDateFormat formater = new java.text.SimpleDateFormat( format );
        java.util.Date date = new java.util.Date();

        System.out.println( formater.format( date ) );

        if (identifConnecte == null || "".equals(identifConnecte)) {
            ServletContextTemplateResolver templateResolver = new ServletContextTemplateResolver(req.getServletContext());
            templateResolver.setPrefix("/WEB-INF/templates/");
            templateResolver.setSuffix(".html");

            WebContext context = new WebContext(req, resp, req.getServletContext());

            TemplateEngine templateEngine = new TemplateEngine();
            templateEngine.setTemplateResolver(templateResolver);

            templateEngine.process("Accueil", context, resp.getWriter());
        } else {
            PrintWriter out = resp.getWriter();
            out.println("<!DOCTYPE html>");
            out.println("<html>");
            out.println("<title>Accueil</title>");
            out.println("<meta charset=\"UTF-8\">");
            out.println("                <meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">");
            out.println("                <link rel=\"stylesheet\" href=\"../CSS/Site.css\">");
            out.println("                <body>");
            out.println("");
            out.println("<!-- Navbar (sit on top) -->");
            out.println("<div class=\"arena-top\">");
            out.println("                <div class=\"arena-bar arena-white arena-wide arena-padding arena-card\">");
            out.println("                <a href=\"Accueil.html\" class=\"arena-bar-item arena-button active\" ><b>ARENA</b> HEI</a>");
            out.println("                <!-- Float links to the right. Hide them on small screens -->");
            out.println("    <div class=\"arena-right arena-hide-small\">");
            out.println("                <a href=\"Evenement\" class=\"arena-bar-item arena-button\">Evènements</a>");
            out.println("                <a href=\"Resultat\" class=\"arena-bar-item arena-button\">Résultats</a>");
            out.println("                <a href=\"Contact\" class=\"arena-bar-item arena-button\">Contact</a>");
            if ("Administrateur".equals(identifConnecte)) {
                out.println("<a href=\"ProfilAdmin\" class=\"arena-bar-item arena-button\">Profil Admin</a>");
            }
            else{
                out.println("<a href=\"Profil\" class=\"arena-bar-item arena-button\">Profil</a>");
            }
            out.println("                </div>");
            out.println("  </div>");
            out.println("</div>");
            out.println("");
            out.println("<!-- Header -->");
            out.println("<header class=\"arena-display-container arena-content arena-wide\" style=\"max-width:1500px;\" id=\"home\">");
            out.println("                <img class=\"arena-image\" src=\"../images/fondecran.jpg\" alt=\"fondecran\" width=\"100%\" height=\"auto\">");
            out.println("                <div class=\"arena-display-middle arena-margin-top arena-center\">");
            out.println("                <h1 class=\"arena-xxlarge arena-text-white\"><img id=\"logoA\" src=\"../images/ARENA.png\"/ width=\"35%\" height=\"auto\"> </span> <span class=\"arena-hide-small arena-text-light-grey shadow\"><b>ARENA</br> <span class=\"arena-hide-small arena-text-light-red shadow\">HEI</span></b></h1>");
            out.println("                </div>");
            out.println("</header>");
            out.println("");
            out.println("<!-- Page content -->");
            out.println("<div class=\"arena-content arena-padding\" style=\"max-width:1564px\">");
            out.println("");
            out.println("                <div class=\"arena-container arena-padding-32\" id=\"presentation\">");
            out.println("                <h3 class=\"arena-border-bottom arena-border-light-grey arena-padding-16\">Présentation</h3>");
            out.println("                <p>L'association ARENA HEI est une association organisant divers évènements d'e-sport comme des LANS, tournois ou rediffusion de parties de jeux videos tels que les LCS (Les League of Legends Championship Series) ou d'autres évènements mondiaux dans le domaine des jeux vidéos.");
            out.println("                </p>");
            out.println("  </div>");
            out.println("");
            out.println("  <!-- Events Section -->");
            out.println("  <div class=\"arena-container arena-padding-32\" id=\"evenements\">");
            out.println("                <h3 class=\"arena-border-bottom arena-border-light-grey arena-padding-16\">Evenements</h3>");
            out.println("                </div>");
            out.println("");
            out.println("  <div class=\"arena-row-padding\">");
            out.println("                <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <div class=\"arena-display-container\">");
            out.println("                <div class=\"arena-display-topleft arena-black arena-padding\">League of Legend</div>");
            out.println("                <img src=\"../arenaimages/house5.jpg\" alt=\"House\" style=\"width:100%\">");
            out.println("                </div>");
            out.println("    </div>");
            out.println("    <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <div class=\"arena-display-container\">");
            out.println("                <div class=\"arena-display-topleft arena-black arena-padding\">CS:GO</div>");
            out.println("                <img src=\"../arenaimages/house2.jpg\" alt=\"House\" style=\"width:100%\">");
            out.println("                </div>");
            out.println("    </div>");
            out.println("    <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <div class=\"arena-display-container\">");
            out.println("                <div class=\"arena-display-topleft arena-black arena-padding\">Hearthstone</div>");
            out.println("                <img src=\"../arenaimages/house3.jpg\" alt=\"House\" style=\"width:100%\">");
            out.println("                </div>");
            out.println("    </div>");
            out.println("    <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <div class=\"arena-display-container\">");
            out.println("                <div class=\"arena-display-topleft arena-black arena-padding\">FIFA</div>");
            out.println("                <img src=\"../arenaimages/house4.jpg\" alt=\"House\" style=\"width:100%\">");
            out.println("                </div>");
            out.println("    </div>");
            out.println("  </div>");
            out.println("");
            out.println("  <div class=\"arena-row-padding\">");
            out.println("                <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <div class=\"arena-display-container\">");
            out.println("                <div class=\"arena-display-topleft arena-black arena-padding\">League of Legend</div>");
            out.println("                <img src=\"../arenaimages/house2.jpg\" alt=\"House\" style=\"width:100%\">");
            out.println("                </div>");
            out.println("    </div>");
            out.println("    <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <div class=\"arena-display-container\">");
            out.println("                <div class=\"arena-display-topleft arena-black arena-padding\">CS:GO</div>");
            out.println("                <img src=\"../arenaimages/house5.jpg\" alt=\"House\" style=\"width:100%\">");
            out.println("                </div>");
            out.println("    </div>");
            out.println("    <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <div class=\"arena-display-container\">");
            out.println("                <div class=\"arena-display-topleft arena-black arena-padding\">Hearthstone</div>");
            out.println("                <img src=\"../arenaimages/house4.jpg\" alt=\"House\" style=\"width:100%\">");
            out.println("                </div>");
            out.println("    </div>");
            out.println("    <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <div class=\"arena-display-container\">");
            out.println("                <div class=\"arena-display-topleft arena-black arena-padding\">FIFA</div>");
            out.println("                <img src=\"../arenaimages/house3.jpg\" alt=\"House\" style=\"width:100%\">");
            out.println("                </div>");
            out.println("    </div>");
            out.println("  </div>");
            out.println("");
            out.println("  <!-- Results Section -->");
            out.println("  <div class=\"arena-container arena-padding-32\" id=\"resultats\">");
            out.println("                <h3 class=\"arena-border-bottom arena-border-light-grey arena-padding-16\">Résultats</h3>");
            out.println("                </div>");
            out.println("");
            out.println("  <div class=\"arena-row-padding\">");
            out.println("                <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <div class=\"arena-display-container\">");
            out.println("                <div class=\"arena-display-topleft arena-black arena-padding\">League of Legend</div>");
            out.println("                <img src=\"../arenaimages/house5.jpg\" alt=\"House\" style=\"width:100%\">");
            out.println("                </div>");
            out.println("    </div>");
            out.println("    <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <div class=\"arena-display-container\">");
            out.println("                <div class=\"arena-display-topleft arena-black arena-padding\">CS:GO</div>");
            out.println("                <img src=\"../arenaimages/house2.jpg\" alt=\"House\" style=\"width:100%\">");
            out.println("                </div>");
            out.println("    </div>");
            out.println("    <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <div class=\"arena-display-container\">");
            out.println("                <div class=\"arena-display-topleft arena-black arena-padding\">Hearthstone</div>");
            out.println("                <img src=\"../arenaimages/house3.jpg\" alt=\"House\" style=\"width:100%\">");
            out.println("                </div>");
            out.println("    </div>");
            out.println("    <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <div class=\"arena-display-container\">");
            out.println("                <div class=\"arena-display-topleft arena-black arena-padding\">FIFA</div>");
            out.println("                <img src=\"../arenaimages/house4.jpg\" alt=\"House\" style=\"width:100%\">");
            out.println("                </div>");
            out.println("    </div>");
            out.println("  </div>");
            out.println("");
            out.println("  <div class=\"arena-row-padding\">");
            out.println("                <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <div class=\"arena-display-container\">");
            out.println("                <div class=\"arena-display-topleft arena-black arena-padding\">League of Legend</div>");
            out.println("                <img src=\"../arenaimages/house2.jpg\" alt=\"House\" style=\"width:100%\">");
            out.println("                </div>");
            out.println("    </div>");
            out.println("    <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <div class=\"arena-display-container\">");
            out.println("                <div class=\"arena-display-topleft arena-black arena-padding\">CS:GO</div>");
            out.println("                <img src=\"../arenaimages/house5.jpg\" alt=\"House\" style=\"width:100%\">");
            out.println("                </div>");
            out.println("    </div>");
            out.println("    <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <div class=\"arena-display-container\">");
            out.println("                <div class=\"arena-display-topleft arena-black arena-padding\">Hearthstone</div>");
            out.println("                <img src=\"../arenaimages/house4.jpg\" alt=\"House\" style=\"width:100%\">");
            out.println("                </div>");
            out.println("    </div>");
            out.println("    <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <div class=\"arena-display-container\">");
            out.println("                <div class=\"arena-display-topleft arena-black arena-padding\">FIFA</div>");
            out.println("                <img src=\"../arenaimages/house3.jpg\" alt=\"House\" style=\"width:100%\">");
            out.println("                </div>");
            out.println("    </div>");
            out.println("  </div>");
            out.println("");
            out.println("");
            out.println("  <!-- Contact Section -->");
            out.println("  <div class=\"arena-container arena-padding-32\" id=\"contact\">");
            out.println("                <h3 class=\"arena-border-bottom arena-border-light-grey arena-padding-16\">Contact</h3>");
            out.println("                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Excepteur sint");
            out.println("        occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco");
            out.println("        laboris nisi ut aliquip ex ea commodo consequat.");
            out.println("    </p>");
            out.println("  </div>");
            out.println("");
            out.println("  <div class=\"arena-row-padding arena-grayscale\">");
            out.println("                <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <img src=\"../arenaimages/team2.jpg\" alt=\"John\" style=\"width:100%\">");
            out.println("                <h3>John Doe</h3>");
            out.println("      <p class=\"arena-opacity\">CEO & Founder</p>");
            out.println("                <p>Phasellus eget enim eu lectus faucibus vestibulum. Suspendisse sodales pellentesque elementum.</p>");
            out.println("      <p><button class=\"arena-button arena-light-grey arena-block\">Connexion</button></p>");
            out.println("                </div>");
            out.println("    <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <img src=\"../arenaimages/team1.jpg\" alt=\"Jane\" style=\"width:100%\">");
            out.println("                <h3>Jane Doe</h3>");
            out.println("      <p class=\"arena-opacity\">Architect</p>");
            out.println("                <p>Phasellus eget enim eu lectus faucibus vestibulum. Suspendisse sodales pellentesque elementum.</p>");
            out.println("      <p><button class=\"arena-button arena-light-grey arena-block\">Connexion</button></p>");
            out.println("                </div>");
            out.println("    <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <img src=\"../arenaimages/team3.jpg\" alt=\"Mike\" style=\"width:100%\">");
            out.println("                <h3>Mike Ross</h3>");
            out.println("      <p class=\"arena-opacity\">Architect</p>");
            out.println("                <p>Phasellus eget enim eu lectus faucibus vestibulum. Suspendisse sodales pellentesque elementum.</p>");
            out.println("      <p><button class=\"arena-button arena-light-grey arena-block\">Connexion</button></p>");
            out.println("                </div>");
            out.println("    <div class=\"arena-col l3 m6 arena-margin-bottom\">");
            out.println("                <img src=\"../arenaimages/team4.jpg\" alt=\"Dan\" style=\"width:100%\">");
            out.println("                <h3>Dan Star</h3>");
            out.println("      <p class=\"arena-opacity\">Architect</p>");
            out.println("                <p>Phasellus eget enim eu lectus faucibus vestibulum. Suspendisse sodales pellentesque elementum.</p>");
            out.println("      <p><button class=\"arena-button arena-light-grey arena-block\">Connexion</button></p>");
            out.println("                </div>");
            out.println("  </div>");
            out.println("");
            out.println("  <!-- Connexion Section -->");
            out.println("  <div class=\"arena-container arena-padding-32\" id=\"Connexion\">");
            out.println("                <h3 class=\"arena-border-bottom arena-border-light-grey arena-padding-16\">Connexion</h3>");
            out.println("                <p>Lets get in touch and talk contact your and our next project.</p>");
            out.println("    <form action=\"../action_page.php\" target=\"_blank\">");
            out.println("                <input class=\"arena-input\" type=\"text\" placeholder=\"Name\" required name=\"Name\">");
            out.println("                <input class=\"arena-input arena-section\" type=\"text\" placeholder=\"Email\" required name=\"Email\">");
            out.println("                <input class=\"arena-input arena-section\" type=\"text\" placeholder=\"Subject\" required name=\"Subject\">");
            out.println("                <input class=\"arena-input arena-section\" type=\"text\" placeholder=\"Comment\" required name=\"Comment\">");
            out.println("                <button class=\"arena-button arena-black arena-section\" type=\"submit\">");
            out.println("                <i class=\"fa fa-paper-plane\"></i> SEND MESSAGE");
            out.println("                </button>");
            out.println("    </form>");
            out.println("  </div>");
            out.println("");
            out.println("<!-- End page content -->");
            out.println("</div>");
            out.println("");
            out.println("<!-- Footer -->");
            out.println("<footer class=\"arena-center arena-black arena-padding-16\">");
            out.println("                <p> Site web réalisé pour l'association ARENA HEI</p>");
            out.println("                </footer>");
            out.println("");
            out.println("</body>");
            out.println("</html>");


        }

    }

}
