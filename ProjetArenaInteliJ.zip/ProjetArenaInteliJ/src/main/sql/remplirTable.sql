DELETE FROM ProjetARENA.utilisateur;

INSERT INTO ProjetARENA.utilisateur(`nom`,`prenom`,`pseudo`,`mot_de_passe`,`email`,`classe`,`notif`) VALUES ('Admin','Admin','Administrateur','ARENAHEI','.@hei.yncrea.fr','H',0);


INSERT INTO ProjetARENA.utilisateur(`nom`,`prenom`,`pseudo`,`mot_de_passe`,`email`,`classe`,`notif`) VALUES ('Denis','Romain','pseudo1','mdp1','romain.denis@hei.yncrea.fr','H44',1);
INSERT INTO ProjetARENA.utilisateur(`nom`,`prenom`,`pseudo`,`mot_de_passe`,`email`,`classe`,`notif`) VALUES ('Carton','Thomas','pseudo2','mdp2','thomas.carton@hei.yncrea.fr','H44',0);
