package servlet;

public class getEvenPrecis {
}
